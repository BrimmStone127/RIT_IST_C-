﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/// <summary>
/// Clayton Brimm 
/// Project 3
/// 5/2/17
/// </summary>
namespace P3starter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Populate();
        }

        public void Populate()
        {
            // Get /about/ information from the API
            string jsonAbout = getRESTData("/about/");

            //Console.WriteLine(jsonAbout);

            // Need to get the data out of the JSON string into an object form
            // that we can easily use
            About about = JToken.Parse(jsonAbout).ToObject<About>();

            // About title
            lbl_aboutTitle.Text = about.title;
            rtb_desc.Text = about.description;
            lbl_about_quoteAuthor.Text = about.quoteAuthor;
            tb_quote.Text = about.quote;

            ////////////////////MINORS/////////////////////
            string jsonMinor = getRESTData("/minors/");
            Minor minor = JToken.Parse(jsonMinor).ToObject<Minor>();
            rtbDegree3.Text = minor.UgMinors[0].title+"\n \n"+minor.UgMinors[0].description +"\n";
            foreach (string MinClass in minor.UgMinors[0].courses)
            {
                rtbDegree3.Text += "\n"+ MinClass;
            }
            rtbDegree4.Text = minor.UgMinors[1].title + "\n \n" + minor.UgMinors[1].description + "\n";
            foreach (string MinClass in minor.UgMinors[1].courses)
            {
                rtbDegree4.Text += "\n" + MinClass;
            }
            rtbDegree5.Text = minor.UgMinors[2].title + "\n \n" + minor.UgMinors[2].description + "\n";
            foreach (string MinClass in minor.UgMinors[0].courses)
            {
                rtbDegree5.Text += "\n" + MinClass;
            }
            rtbDegree6.Text = minor.UgMinors[3].title + "\n \n" + minor.UgMinors[3].description + "\n";
            foreach (string MinClass in minor.UgMinors[3].courses)
            {
                rtbDegree6.Text += "\n" + MinClass;
            }
            rtbDegree7.Text = minor.UgMinors[4].title + "\n \n" + minor.UgMinors[4].description + "\n";
            foreach (string MinClass in minor.UgMinors[4].courses)
            {
                rtbDegree7.Text += "\n" + MinClass;
            }
            rtbDegree8.Text = minor.UgMinors[5].title + "\n \n" + minor.UgMinors[5].description + "\n";
            foreach (string MinClass in minor.UgMinors[5].courses)
            {
                rtbDegree8.Text += "\n" + MinClass;
            }
            rtbDegree9.Text = minor.UgMinors[6].title + "\n \n" + minor.UgMinors[6].description + "\n";
            foreach (string MinClass in minor.UgMinors[6].courses)
            {
                rtbDegree9.Text += "\n" + MinClass;
            }
            rtbDegree10.Text = minor.UgMinors[7].title + "\n \n" + minor.UgMinors[7].description + "\n";
            foreach (string MinClass in minor.UgMinors[7].courses)
            {
                rtbDegree10.Text += "\n" + MinClass;
            }
            ///////////////////RESEARCH///////////////////////////
            string jsonResearch = getRESTData("/research/");
            Research research = JToken.Parse(jsonResearch).ToObject<Research>();
            foreach(ByFaculty fac in research.byFaculty)
            {
                cbResearch1.Items.Add(fac.facultyName);
            }
            foreach(ByInterestArea inter in research.byInterestArea)
            {
                cbResearch2.Items.Add(inter.areaName);
            }


            ///////////////////RESOURCES//////////////////////////
            string jsonRes = getRESTData("/resources/");
            Resources resources = JToken.Parse(jsonRes).ToObject<Resources>();
            //Study Abroad
            rtbAbroad.Text = resources.studyAbroad.description;
            lblAbroad1.Text = resources.studyAbroad.places[0].nameOfPlace;
            rtbAbroad1.Text = resources.studyAbroad.places[0].description;
            lblAbroad2.Text = resources.studyAbroad.places[1].nameOfPlace;
            rtbAbroad2.Text = resources.studyAbroad.places[1].description;
            //Student Services
            //lblServices1.Text = resources.studentServices.academicAdvisors.title;
            rtbServices1.Text = resources.studentServices.academicAdvisors.description;
            linkServices1.Text = resources.studentServices.academicAdvisors.faq.contentHref;
            lblServices2.Text = resources.studentServices.professonalAdvisors.title;
            foreach (AdvisorInformation advisor in resources.studentServices.professonalAdvisors.advisorInformation)
            {
                rtbServices2.Text += "\n" + advisor.name + "\t" + advisor.department + "\t" + advisor.email + "\n";
            }
            //lblServices3.Text = resources.studentServices.academicAdvisors.title;
            //rtbServices3.Text = resources.studentServices.academicAdvisors.description;
            lblServices4.Text = resources.studentServices.istMinorAdvising.title;
            foreach (MinorAdvisorInformation minorAdvisor in resources.studentServices.istMinorAdvising.minorAdvisorInformation)
            {
                rtbServices4.Text += "\n" + minorAdvisor.title + "\t - \t" + minorAdvisor.advisor + "\t - \t" + minorAdvisor.email + "\n";
            }
            //tutors And Lab Information
            lblLab1.Text = resources.tutorsAndLabInformation.title;
            rtbLab1.Text = resources.tutorsAndLabInformation.description;
            linkLab1.Text = resources.tutorsAndLabInformation.tutoringLabHoursLink;
            //student ambassadors
            lblAmbassador1.Text = resources.studentAmbassadors.title;
            pbAmbassador1.ImageLocation = resources.studentAmbassadors.ambassadorsImageSource;
            foreach (SubSectionContent sub in resources.studentAmbassadors.subSectionContent)
            {
                rtbAmbassador1.Text += "\n" + sub.title + "\n" + sub.description + "\n";
            }
            //forms
            gbForms1.Text = "Graduate Forms";
            gbForms2.Text = "Undergraduate Forms";
            foreach (GraduateForm form in resources.forms.graduateForms)
            {
                rtbForms1.Text += "\n" + form.formName + "\n" + form.href + "\n";
            }
            foreach (UndergraduateForm form in resources.forms.undergraduateForms)
            {
                rtbForms2.Text += "\n" + form.formName + "\n" + form.href + "\n";
            }
            //coop enrollment
            lblCoop1.Text = resources.coopEnrollment.title;
            foreach (EnrollmentInformationContent enroll in resources.coopEnrollment.enrollmentInformationContent)
            {
                rtbCoop1.Text += "\n" + enroll.title + "\n" + enroll.description + "\n";
            }
            rtbCoop1.Text += resources.coopEnrollment.RITJobZoneGuidelink;

            /////////////////NEWS////////////////////////////////////
            string jsonNews = getRESTData("/news/");
            News news = JToken.Parse(jsonNews).ToObject<News>();
            foreach (Year year in news.year)
            {
                rtbNews1.Text += "\n" + year.date + "\n" + year.title + "\n" + year.description + "\n";
            }
            foreach (Older old in news.older)
            {
                rtbNews2.Text += "\n" + old.date + "\n" + old.title + "\n" + old.description +"\n";
            }

            //////////////////CAREERS/////////////////////////////
            string jsonCareer = getRESTData("/employment/");
            Career career = JToken.Parse(jsonCareer).ToObject<Career>();
            lblCareer1.Text = career.introduction.title;
            rtbCareer1.Text = career.introduction.content[0].description;
            rtbCareer2.Text = career.introduction.content[1].description;
            lblCareer2.Text = career.degreeStatistics.statistics[0].value + "\n" + career.degreeStatistics.statistics[0].description;
            lblCareer3.Text = career.degreeStatistics.statistics[1].value + "\n" + career.degreeStatistics.statistics[1].description;
            lblCareer4.Text = career.degreeStatistics.statistics[2].value + "\n" + career.degreeStatistics.statistics[2].description;
            foreach(string employee in career.employers.employerNames)
            {
                lblCareer5.Text += employee + "\n";
            }
            foreach (string careers in career.careers.careerNames)
            {
                lblCareer6.Text += careers + "\n";
            }
            int row = 1;
           
            foreach(CoopInformation coop in career.coopTable.coopInformation)
            {
                rtbOne.Text += coop.employer + "\n";
                rtbTwo.Text += coop.degree + "\n";
                rtbThree.Text += coop.city + "\n";
                rtbFour.Text += coop.term + "\n";
                row++;
               
            }
            int row2 = 1;

            foreach (ProfessionalEmploymentInformation emp in career.employmentTable.professionalEmploymentInformation)
            {
                rtb1.Text += emp.employer + "\n";
                rtb2.Text += emp.degree + "\n";
                rtb3.Text += emp.city + "\n";
                rtb4.Text += emp.title + "\n";
                row++;
               
            }

            /*
            tlpCoop.Controls.Add(new Label() { Text = "Street, City, State" }, 1, panel.RowCount - 1);
            tlpCoop.Controls.Add(new Label() { Text = "888888888888" }, 2, panel.RowCount - 1);
            tlpCoop.Controls.Add(new Label() { Text = "xxxxxxx@gmail.com" }, 3, panel.RowCount - 1);
            */
            /////////////DEGREES///////////////////////////
            string jsonDegree = getRESTData("/degrees/");
            Degree degree = JToken.Parse(jsonDegree).ToObject<Degree>();
            foreach(Undergraduate under in degree.undergraduate)
            {
                rtbDegree1.Text += under.title + "\n" + under.description +"\n";
                rtbDegree1.Text += "Concentrations: " + "\n";
                foreach(string conc in under.concentrations)
                {
                    rtbDegree1.Text += conc + "\t - \t";
                }
                rtbDegree1.Text += "\n \n";
            }
            foreach (Graduate grad in degree.graduate)
            {
                rtbDegree2.Text += grad.title + "\n" + grad.description +"\n";
                rtbDegree2.Text += "Concentrations: " + "\n";
                if (grad.concentrations != null)
                {
                    foreach (string conc in grad.concentrations)
                    {
                        rtbDegree2.Text += conc + "\t - \t";
                    }
                }
                else
                {
                    foreach (string conc in grad.availableCertificates)
                    {
                        rtbDegree2.Text += conc + "\t - \t";
                    }
                }
                rtbDegree2.Text += "\n \n";
            }
        }

        //////////////Faculty//////////////////////////
        #region Common method to getRESTData( url ) from the API
        // Get the REST API information from ist.rit.edu
        private string getRESTData(string url)
        {
            const string baseUri = "http://ist.rit.edu/api";

            // connect to the API
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(baseUri + url);

            try
            {
                // Wait and get the response for this web request
                WebResponse response = request.GetResponse();

                // Using the response stream from the web request
                // get the information requested
                using (Stream responseStream = response.GetResponseStream())
                {
                    StreamReader reader = new StreamReader(responseStream, Encoding.UTF8);
                    return reader.ReadToEnd();
                }
            }
            catch (WebException we)     // Just because we have an exception,
            {                           //  we still have information to use for debug
                // get the response 
                WebResponse err = we.Response;
                using (Stream responseStream = err.GetResponseStream())
                {
                    StreamReader r = new StreamReader(responseStream, Encoding.UTF8);
                    // do something with the error
                    string errorText = r.ReadToEnd();
                    Console.WriteLine("ERROR: " + errorText);
                }
                // Can't do anything more with this exception. 
                // Throw it. Make it someone elses problem.
                throw;
            }

            
        }   // end getRESTData()
        #endregion
        int button1 = -1;
        int button2 = -2;
        int button3 = -3;
        bool selected;

        private void button4_Click(object sender, EventArgs e)
        {
            selected = true;
            lblPeople4.Text = "IST Department Faculty";
            button1 = button1 + 3;
            button2 = button2 + 3;
            button3 = button3 + 3;
            string jsonPeople = getRESTData("/people/");
            People people = JToken.Parse(jsonPeople).ToObject<People>();
            if (button1 >= people.faculty.Count)
            {
                button1 = 2;
            }
            if (button2 >= people.faculty.Count)
            {
                button2 = 1;
            }
            if (button3 >= people.faculty.Count)
            {
                button3 = 0;
            }
            pbPeople1.ImageLocation = people.faculty[button1].imagePath;
            lblPeople1.Text = people.faculty[button1].name;
            rtbPeople1.Text = " " + people.faculty[button1].title + "\n Username: " + people.faculty[button1].username + "\n";
            rtbPeople1.Text += " Area of interest: " + people.faculty[button1].interestArea + "\n office: " + people.faculty[button1].office + "\n phone number: " + people.faculty[button1].phone + "\n email: " + people.faculty[button1].email + "\n website: " + people.faculty[button1].website;
            pbPeople2.ImageLocation = people.faculty[button2].imagePath;
            lblPeople2.Text = people.faculty[button2].name;
            rtbPeople2.Text = " " + people.faculty[button2].title + "\n Username: " + people.faculty[button2].username + "\n";
            rtbPeople2.Text += " Area of interest: " + people.faculty[button2].interestArea + "\n office: " + people.faculty[button2].office + "\n phone number: " + people.faculty[button2].phone + "\n email: " + people.faculty[button2].email + "\n website: " + people.faculty[button2].website;
            pbPeople3.ImageLocation = people.faculty[button3].imagePath;
            lblPeople3.Text = people.faculty[button3].name;
            rtbPeople3.Text = " " + people.faculty[button3].title + "\n Username: " + people.faculty[button3].username + "\n";
            rtbPeople3.Text += " Area of interest: " + people.faculty[button3].interestArea + "\n office: " + people.faculty[button3].office + "\n phone number: " + people.faculty[button3].phone + "\n email: " + people.faculty[button3].email + "\n website: " + people.faculty[button3].website;
        }

        private void btnPeople3_Click(object sender, EventArgs e)
        {
            selected = false;
            lblPeople4.Text = "IST Department Staff";
            button1 = button1 + 3;
            button2 = button2 + 3;
            button3 = button3 + 3;
            string jsonPeople = getRESTData("/people/");
            People people = JToken.Parse(jsonPeople).ToObject<People>();
            if (button1 >= people.staff.Count)
            {
                button1 = 2;
            }
            if (button2 >= people.staff.Count)
            {
                button2 = 1;
            }
            if (button3 >= people.staff.Count)
            {
                button3 = 0;
            }
            pbPeople1.ImageLocation = people.staff[button1].imagePath;
            lblPeople1.Text = people.staff[button1].name;
            rtbPeople1.Text = " " + people.staff[button1].title + "\n Username: " + people.staff[button1].username + "\n";
            rtbPeople1.Text += " Area of interest: " + people.staff[button1].interestArea + "\n office: " + people.staff[button1].office + "\n phone number: " + people.staff[button1].phone + "\n email: " + people.staff[button1].email + "\n website: " + people.staff[button1].website;
            pbPeople2.ImageLocation = people.staff[button2].imagePath;
            lblPeople2.Text = people.staff[button2].name;
            rtbPeople2.Text = " " + people.staff[button2].title + "\n Username: " + people.staff[button2].username + "\n";
            rtbPeople2.Text += " Area of interest: " + people.staff[button2].interestArea + "\n office: " + people.staff[button2].office + "\n phone number: " + people.staff[button2].phone + "\n email: " + people.staff[button2].email + "\n website: " + people.staff[button2].website;
            pbPeople3.ImageLocation = people.staff[button3].imagePath;
            lblPeople3.Text = people.staff[button3].name;
            rtbPeople3.Text = " " + people.staff[button3].title + "\n Username: " + people.staff[button3].username + "\n";
            rtbPeople3.Text += " Area of interest: " + people.staff[button3].interestArea + "\n office: " + people.staff[button3].office + "\n phone number: " + people.staff[button3].phone + "\n email: " + people.staff[button3].email + "\n website: " + people.staff[button3].website;
        }

        private void btnPeople1_Click(object sender, EventArgs e)
        {
            if (selected == true)
            {
                button1 = button1 + 3;
                button2 = button2 + 3;
                button3 = button3 + 3;
                string jsonPeople = getRESTData("/people/");
                People people = JToken.Parse(jsonPeople).ToObject<People>();
                if (button1 >= people.faculty.Count)
                {
                    button1 = 2;
                }
                if (button2 >= people.faculty.Count)
                {
                    button2 = 1;
                }
                if (button3 >= people.faculty.Count)
                {
                    button3 = 0;
                }
                pbPeople1.ImageLocation = people.faculty[button1].imagePath;
                lblPeople1.Text = people.faculty[button1].name;
                rtbPeople1.Text = " " + people.faculty[button1].title + "\n Username: " + people.faculty[button1].username + "\n";
                rtbPeople1.Text += " Area of interest: " + people.faculty[button1].interestArea + "\n office: " + people.faculty[button1].office + "\n phone number: " + people.faculty[button1].phone + "\n email: " + people.faculty[button1].email + "\n website: " + people.faculty[button1].website;
                pbPeople2.ImageLocation = people.faculty[button2].imagePath;
                lblPeople2.Text = people.faculty[button2].name;
                rtbPeople2.Text = " " + people.faculty[button2].title + "\n Username: " + people.faculty[button2].username + "\n";
                rtbPeople2.Text += " Area of interest: " + people.faculty[button2].interestArea + "\n office: " + people.faculty[button2].office + "\n phone number: " + people.faculty[button2].phone + "\n email: " + people.faculty[button2].email + "\n website: " + people.faculty[button2].website;
                pbPeople3.ImageLocation = people.faculty[button3].imagePath;
                lblPeople3.Text = people.faculty[button3].name;
                rtbPeople3.Text = " " + people.faculty[button3].title + "\n Username: " + people.faculty[button3].username + "\n";
                rtbPeople3.Text += " Area of interest: " + people.faculty[button3].interestArea + "\n office: " + people.faculty[button3].office + "\n phone number: " + people.faculty[button3].phone + "\n email: " + people.faculty[button3].email + "\n website: " + people.faculty[button3].website;
            }
            else if(selected == false)
            {
                button1 = button1 + 3;
                button2 = button2 + 3;
                button3 = button3 + 3;
                string jsonPeople = getRESTData("/people/");
                People people = JToken.Parse(jsonPeople).ToObject<People>();
                if (button1 >= people.staff.Count)
                {
                    button1 = 2;
                }
                if (button2 >= people.staff.Count)
                {
                    button2 = 1;
                }
                if (button3 >= people.staff.Count)
                {
                    button3 = 0;
                }
                pbPeople1.ImageLocation = people.staff[button1].imagePath;
                lblPeople1.Text = people.staff[button1].name;
                rtbPeople1.Text = " " + people.staff[button1].title + "\n Username: " + people.staff[button1].username + "\n";
                rtbPeople1.Text += " Area of interest: " + people.staff[button1].interestArea + "\n office: " + people.staff[button1].office + "\n phone number: " + people.staff[button1].phone + "\n email: " + people.staff[button1].email + "\n website: " + people.staff[button1].website;
                pbPeople2.ImageLocation = people.staff[button2].imagePath;
                lblPeople2.Text = people.staff[button2].name;
                rtbPeople2.Text = " " + people.staff[button2].title + "\n Username: " + people.staff[button2].username + "\n";
                rtbPeople2.Text += " Area of interest: " + people.staff[button2].interestArea + "\n office: " + people.staff[button2].office + "\n phone number: " + people.staff[button2].phone + "\n email: " + people.staff[button2].email + "\n website: " + people.staff[button2].website;
                pbPeople3.ImageLocation = people.staff[button3].imagePath;
                lblPeople3.Text = people.staff[button3].name;
                rtbPeople3.Text = " " + people.staff[button3].title + "\n Username: " + people.staff[button3].username + "\n";
                rtbPeople3.Text += " Area of interest: " + people.staff[button3].interestArea + "\n office: " + people.staff[button3].office + "\n phone number: " + people.staff[button3].phone + "\n email: " + people.staff[button3].email + "\n website: " + people.staff[button3].website;
            }
        }

        private void cbResearch1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            string jsonResearch = getRESTData("/research/");
            Research research = JToken.Parse(jsonResearch).ToObject<Research>();
            int selectedNum = cbResearch1.SelectedIndex;
            rtbResearch1.Text = research.byFaculty[selectedNum].facultyName+"\n";
            rtbResearch1.Text += research.byFaculty[selectedNum].username + "\n \n"+"Citations:\n";
            foreach(string citate in research.byFaculty[selectedNum].citations)
            {
                rtbResearch1.Text +="\n"+ citate+"\n";
            }
        }
        private void cbResearch2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string jsonResearch = getRESTData("/research/");
            Research research = JToken.Parse(jsonResearch).ToObject<Research>();
            int selectedNum = cbResearch2.SelectedIndex;
            rtbResearch1.Text = research.byInterestArea[selectedNum].areaName + "\n \n" + "Citations:\n";
            foreach (string citate in research.byInterestArea[selectedNum].citations)
            {
                rtbResearch1.Text += "\n" + citate + "\n";
            }
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //no
        }

        private void label1_Click(object sender, EventArgs e)
        {
            //no
        }

        private void lblServices4_Click(object sender, EventArgs e)
        {
            //no
        }

        private void tabPage7_Click(object sender, EventArgs e)
        {
            //no
        }

        private void tabPage13_Click(object sender, EventArgs e)
        {
            //no
        }

        private void lbl_about_quoteAuthor_Click(object sender, EventArgs e)
        {
            //no
        }

        private void lbl_aboutTitle_Click(object sender, EventArgs e)
        {
            //no
        }

        private void pbPeople1_Click(object sender, EventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void lblPeople4_Click(object sender, EventArgs e)
        {

        }

        private void lblCareer2_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void rtbAbroad1_TextChanged(object sender, EventArgs e)
        {

        }

        private void rtbAbroad2_TextChanged(object sender, EventArgs e)
        {

        }

        private void rtbForms2_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblServices1_Click(object sender, EventArgs e)
        {

        }

        private void rtbServices2_TextChanged(object sender, EventArgs e)
        {

        }

        private void linkServices1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        
    }
}
