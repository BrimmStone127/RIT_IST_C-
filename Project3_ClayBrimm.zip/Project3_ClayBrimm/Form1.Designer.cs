﻿namespace P3starter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_aboutTitle = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbl_about_quoteAuthor = new System.Windows.Forms.Label();
            this.rtb_desc = new System.Windows.Forms.RichTextBox();
            this.tb_quote = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnPeople3 = new System.Windows.Forms.Button();
            this.btnPeople2 = new System.Windows.Forms.Button();
            this.lblPeople4 = new System.Windows.Forms.Label();
            this.rtbPeople3 = new System.Windows.Forms.RichTextBox();
            this.rtbPeople2 = new System.Windows.Forms.RichTextBox();
            this.lblPeople3 = new System.Windows.Forms.Label();
            this.lblPeople2 = new System.Windows.Forms.Label();
            this.pbPeople2 = new System.Windows.Forms.PictureBox();
            this.pbPeople3 = new System.Windows.Forms.PictureBox();
            this.lblPeople1 = new System.Windows.Forms.Label();
            this.rtbPeople1 = new System.Windows.Forms.RichTextBox();
            this.btnPeople1 = new System.Windows.Forms.Button();
            this.pbPeople1 = new System.Windows.Forms.PictureBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabControl6 = new System.Windows.Forms.TabControl();
            this.tabPage26 = new System.Windows.Forms.TabPage();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblCareer6 = new System.Windows.Forms.Label();
            this.lblCareer5 = new System.Windows.Forms.Label();
            this.lblCareer4 = new System.Windows.Forms.Label();
            this.lblCareer3 = new System.Windows.Forms.Label();
            this.lblCareer2 = new System.Windows.Forms.Label();
            this.tabPage27 = new System.Windows.Forms.TabPage();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.tabPage28 = new System.Windows.Forms.TabPage();
            this.tabPage29 = new System.Windows.Forms.TabPage();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.rtbCareer2 = new System.Windows.Forms.RichTextBox();
            this.rtbCareer1 = new System.Windows.Forms.RichTextBox();
            this.lblCareer1 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.cbResearch2 = new System.Windows.Forms.ComboBox();
            this.cbResearch1 = new System.Windows.Forms.ComboBox();
            this.rtbResearch1 = new System.Windows.Forms.RichTextBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.pbAmbassador1 = new System.Windows.Forms.PictureBox();
            this.rtbAmbassador1 = new System.Windows.Forms.RichTextBox();
            this.lblAmbassador1 = new System.Windows.Forms.Label();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.lblAbroad2 = new System.Windows.Forms.Label();
            this.lblAbroad1 = new System.Windows.Forms.Label();
            this.rtbAbroad2 = new System.Windows.Forms.RichTextBox();
            this.rtbAbroad1 = new System.Windows.Forms.RichTextBox();
            this.rtbAbroad = new System.Windows.Forms.RichTextBox();
            this.richTextBox3 = new System.Windows.Forms.RichTextBox();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.tabControl4 = new System.Windows.Forms.TabControl();
            this.tabPage22 = new System.Windows.Forms.TabPage();
            this.lblServices2 = new System.Windows.Forms.Label();
            this.linkServices1 = new System.Windows.Forms.LinkLabel();
            this.rtbServices2 = new System.Windows.Forms.RichTextBox();
            this.rtbServices1 = new System.Windows.Forms.RichTextBox();
            this.tabPage24 = new System.Windows.Forms.TabPage();
            this.lblServices4 = new System.Windows.Forms.Label();
            this.rtbServices4 = new System.Windows.Forms.RichTextBox();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.linkLab1 = new System.Windows.Forms.Label();
            this.rtbLab1 = new System.Windows.Forms.RichTextBox();
            this.lblLab1 = new System.Windows.Forms.Label();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.gbForms2 = new System.Windows.Forms.GroupBox();
            this.rtbForms2 = new System.Windows.Forms.RichTextBox();
            this.gbForms1 = new System.Windows.Forms.GroupBox();
            this.rtbForms1 = new System.Windows.Forms.RichTextBox();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.rtbCoop1 = new System.Windows.Forms.RichTextBox();
            this.lblCoop1 = new System.Windows.Forms.Label();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.rtbNews2 = new System.Windows.Forms.RichTextBox();
            this.rtbNews1 = new System.Windows.Forms.RichTextBox();
            this.lblNews2 = new System.Windows.Forms.Label();
            this.lblNews1 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.label8 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl5 = new System.Windows.Forms.TabControl();
            this.tabPage23 = new System.Windows.Forms.TabPage();
            this.rtbDegree2 = new System.Windows.Forms.RichTextBox();
            this.tabPage25 = new System.Windows.Forms.TabPage();
            this.rtbDegree1 = new System.Windows.Forms.RichTextBox();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage15 = new System.Windows.Forms.TabPage();
            this.rtbDegree3 = new System.Windows.Forms.RichTextBox();
            this.tabPage14 = new System.Windows.Forms.TabPage();
            this.rtbDegree4 = new System.Windows.Forms.RichTextBox();
            this.tabPage16 = new System.Windows.Forms.TabPage();
            this.rtbDegree5 = new System.Windows.Forms.RichTextBox();
            this.tabPage17 = new System.Windows.Forms.TabPage();
            this.rtbDegree6 = new System.Windows.Forms.RichTextBox();
            this.tabPage18 = new System.Windows.Forms.TabPage();
            this.rtbDegree7 = new System.Windows.Forms.RichTextBox();
            this.tabPage19 = new System.Windows.Forms.TabPage();
            this.rtbDegree8 = new System.Windows.Forms.RichTextBox();
            this.tabPage20 = new System.Windows.Forms.TabPage();
            this.rtbDegree9 = new System.Windows.Forms.RichTextBox();
            this.tabPage21 = new System.Windows.Forms.TabPage();
            this.rtbDegree10 = new System.Windows.Forms.RichTextBox();
            this.tabPage30 = new System.Windows.Forms.TabPage();
            this.rtbOne = new System.Windows.Forms.RichTextBox();
            this.rtbFour = new System.Windows.Forms.RichTextBox();
            this.rtbThree = new System.Windows.Forms.RichTextBox();
            this.rtbTwo = new System.Windows.Forms.RichTextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.rtb2 = new System.Windows.Forms.RichTextBox();
            this.rtb3 = new System.Windows.Forms.RichTextBox();
            this.rtb4 = new System.Windows.Forms.RichTextBox();
            this.rtb1 = new System.Windows.Forms.RichTextBox();
            this.webBrowser2 = new System.Windows.Forms.WebBrowser();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbPeople2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPeople3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPeople1)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.tabControl6.SuspendLayout();
            this.tabPage26.SuspendLayout();
            this.tabPage27.SuspendLayout();
            this.tabPage28.SuspendLayout();
            this.tabPage29.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbAmbassador1)).BeginInit();
            this.tabPage8.SuspendLayout();
            this.tabPage9.SuspendLayout();
            this.tabControl4.SuspendLayout();
            this.tabPage22.SuspendLayout();
            this.tabPage24.SuspendLayout();
            this.tabPage10.SuspendLayout();
            this.tabPage11.SuspendLayout();
            this.gbForms2.SuspendLayout();
            this.gbForms1.SuspendLayout();
            this.tabPage12.SuspendLayout();
            this.tabPage13.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabControl5.SuspendLayout();
            this.tabPage23.SuspendLayout();
            this.tabPage25.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage15.SuspendLayout();
            this.tabPage14.SuspendLayout();
            this.tabPage16.SuspendLayout();
            this.tabPage17.SuspendLayout();
            this.tabPage18.SuspendLayout();
            this.tabPage19.SuspendLayout();
            this.tabPage20.SuspendLayout();
            this.tabPage21.SuspendLayout();
            this.tabPage30.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_aboutTitle
            // 
            this.lbl_aboutTitle.AutoSize = true;
            this.lbl_aboutTitle.Font = new System.Drawing.Font("Arial", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_aboutTitle.Location = new System.Drawing.Point(946, 71);
            this.lbl_aboutTitle.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbl_aboutTitle.Name = "lbl_aboutTitle";
            this.lbl_aboutTitle.Size = new System.Drawing.Size(632, 60);
            this.lbl_aboutTitle.TabIndex = 0;
            this.lbl_aboutTitle.Text = "{ place About title here }";
            this.lbl_aboutTitle.Click += new System.EventHandler(this.lbl_aboutTitle_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(811, 911);
            this.label2.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 38);
            this.label2.TabIndex = 1;
            this.label2.Text = "Quote:";
            // 
            // lbl_about_quoteAuthor
            // 
            this.lbl_about_quoteAuthor.AutoSize = true;
            this.lbl_about_quoteAuthor.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_about_quoteAuthor.Location = new System.Drawing.Point(811, 1263);
            this.lbl_about_quoteAuthor.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbl_about_quoteAuthor.Name = "lbl_about_quoteAuthor";
            this.lbl_about_quoteAuthor.Size = new System.Drawing.Size(483, 38);
            this.lbl_about_quoteAuthor.TabIndex = 2;
            this.lbl_about_quoteAuthor.Text = "{ place About quote author here }";
            this.lbl_about_quoteAuthor.Click += new System.EventHandler(this.lbl_about_quoteAuthor_Click);
            // 
            // rtb_desc
            // 
            this.rtb_desc.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.rtb_desc.BackColor = System.Drawing.SystemColors.Window;
            this.rtb_desc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtb_desc.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtb_desc.Location = new System.Drawing.Point(405, 279);
            this.rtb_desc.Margin = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.rtb_desc.Name = "rtb_desc";
            this.rtb_desc.ReadOnly = true;
            this.rtb_desc.Size = new System.Drawing.Size(2443, 327);
            this.rtb_desc.TabIndex = 4;
            this.rtb_desc.Text = "";
            // 
            // tb_quote
            // 
            this.tb_quote.BackColor = System.Drawing.SystemColors.Window;
            this.tb_quote.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_quote.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_quote.Location = new System.Drawing.Point(818, 992);
            this.tb_quote.Margin = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.tb_quote.Multiline = true;
            this.tb_quote.Name = "tb_quote";
            this.tb_quote.ReadOnly = true;
            this.tb_quote.Size = new System.Drawing.Size(1358, 209);
            this.tb_quote.TabIndex = 5;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage30);
            this.tabControl1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(28, 26);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(5);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(3250, 1562);
            this.tabControl1.TabIndex = 8;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.rtb_desc);
            this.tabPage1.Controls.Add(this.lbl_aboutTitle);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.tb_quote);
            this.tabPage1.Controls.Add(this.lbl_about_quoteAuthor);
            this.tabPage1.Location = new System.Drawing.Point(10, 62);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(5);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(5);
            this.tabPage1.Size = new System.Drawing.Size(3230, 1490);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "About";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnPeople3);
            this.tabPage2.Controls.Add(this.btnPeople2);
            this.tabPage2.Controls.Add(this.lblPeople4);
            this.tabPage2.Controls.Add(this.rtbPeople3);
            this.tabPage2.Controls.Add(this.rtbPeople2);
            this.tabPage2.Controls.Add(this.lblPeople3);
            this.tabPage2.Controls.Add(this.lblPeople2);
            this.tabPage2.Controls.Add(this.pbPeople2);
            this.tabPage2.Controls.Add(this.pbPeople3);
            this.tabPage2.Controls.Add(this.lblPeople1);
            this.tabPage2.Controls.Add(this.rtbPeople1);
            this.tabPage2.Controls.Add(this.btnPeople1);
            this.tabPage2.Controls.Add(this.pbPeople1);
            this.tabPage2.Location = new System.Drawing.Point(10, 62);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(5);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(5);
            this.tabPage2.Size = new System.Drawing.Size(3230, 1490);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Faculty/Staff";
            this.tabPage2.UseVisualStyleBackColor = true;
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // btnPeople3
            // 
            this.btnPeople3.BackColor = System.Drawing.Color.DimGray;
            this.btnPeople3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPeople3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnPeople3.Location = new System.Drawing.Point(1820, 45);
            this.btnPeople3.Margin = new System.Windows.Forms.Padding(5);
            this.btnPeople3.Name = "btnPeople3";
            this.btnPeople3.Size = new System.Drawing.Size(444, 107);
            this.btnPeople3.TabIndex = 12;
            this.btnPeople3.Text = "Click Here to see our staff";
            this.btnPeople3.UseVisualStyleBackColor = false;
            this.btnPeople3.Click += new System.EventHandler(this.btnPeople3_Click);
            // 
            // btnPeople2
            // 
            this.btnPeople2.BackColor = System.Drawing.Color.DimGray;
            this.btnPeople2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPeople2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnPeople2.Location = new System.Drawing.Point(432, 45);
            this.btnPeople2.Margin = new System.Windows.Forms.Padding(5);
            this.btnPeople2.Name = "btnPeople2";
            this.btnPeople2.Size = new System.Drawing.Size(412, 107);
            this.btnPeople2.TabIndex = 11;
            this.btnPeople2.Text = "Click Here to see our faculty";
            this.btnPeople2.UseVisualStyleBackColor = false;
            this.btnPeople2.Click += new System.EventHandler(this.button4_Click);
            // 
            // lblPeople4
            // 
            this.lblPeople4.AutoSize = true;
            this.lblPeople4.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPeople4.Location = new System.Drawing.Point(1102, 45);
            this.lblPeople4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblPeople4.Name = "lblPeople4";
            this.lblPeople4.Size = new System.Drawing.Size(133, 60);
            this.lblPeople4.TabIndex = 10;
            this.lblPeople4.Text = "Staff";
            this.lblPeople4.Click += new System.EventHandler(this.lblPeople4_Click);
            // 
            // rtbPeople3
            // 
            this.rtbPeople3.Location = new System.Drawing.Point(1753, 885);
            this.rtbPeople3.Margin = new System.Windows.Forms.Padding(5);
            this.rtbPeople3.Name = "rtbPeople3";
            this.rtbPeople3.Size = new System.Drawing.Size(651, 350);
            this.rtbPeople3.TabIndex = 9;
            this.rtbPeople3.Text = "";
            // 
            // rtbPeople2
            // 
            this.rtbPeople2.Location = new System.Drawing.Point(1052, 885);
            this.rtbPeople2.Margin = new System.Windows.Forms.Padding(5);
            this.rtbPeople2.Name = "rtbPeople2";
            this.rtbPeople2.Size = new System.Drawing.Size(639, 350);
            this.rtbPeople2.TabIndex = 8;
            this.rtbPeople2.Text = "";
            // 
            // lblPeople3
            // 
            this.lblPeople3.AutoSize = true;
            this.lblPeople3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPeople3.Location = new System.Drawing.Point(1970, 634);
            this.lblPeople3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblPeople3.Name = "lblPeople3";
            this.lblPeople3.Size = new System.Drawing.Size(178, 38);
            this.lblPeople3.TabIndex = 7;
            this.lblPeople3.Text = "Staff Name";
            // 
            // lblPeople2
            // 
            this.lblPeople2.AutoSize = true;
            this.lblPeople2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPeople2.Location = new System.Drawing.Point(1308, 634);
            this.lblPeople2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblPeople2.Name = "lblPeople2";
            this.lblPeople2.Size = new System.Drawing.Size(178, 38);
            this.lblPeople2.TabIndex = 6;
            this.lblPeople2.Text = "Staff Name";
            // 
            // pbPeople2
            // 
            this.pbPeople2.Location = new System.Drawing.Point(1145, 198);
            this.pbPeople2.Margin = new System.Windows.Forms.Padding(5);
            this.pbPeople2.Name = "pbPeople2";
            this.pbPeople2.Size = new System.Drawing.Size(432, 431);
            this.pbPeople2.TabIndex = 5;
            this.pbPeople2.TabStop = false;
            // 
            // pbPeople3
            // 
            this.pbPeople3.Location = new System.Drawing.Point(1820, 198);
            this.pbPeople3.Margin = new System.Windows.Forms.Padding(5);
            this.pbPeople3.Name = "pbPeople3";
            this.pbPeople3.Size = new System.Drawing.Size(444, 431);
            this.pbPeople3.TabIndex = 4;
            this.pbPeople3.TabStop = false;
            // 
            // lblPeople1
            // 
            this.lblPeople1.AutoSize = true;
            this.lblPeople1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPeople1.Location = new System.Drawing.Point(562, 634);
            this.lblPeople1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblPeople1.Name = "lblPeople1";
            this.lblPeople1.Size = new System.Drawing.Size(178, 38);
            this.lblPeople1.TabIndex = 3;
            this.lblPeople1.Text = "Staff Name";
            // 
            // rtbPeople1
            // 
            this.rtbPeople1.Location = new System.Drawing.Point(363, 885);
            this.rtbPeople1.Margin = new System.Windows.Forms.Padding(5);
            this.rtbPeople1.Name = "rtbPeople1";
            this.rtbPeople1.Size = new System.Drawing.Size(619, 350);
            this.rtbPeople1.TabIndex = 2;
            this.rtbPeople1.Text = "";
            // 
            // btnPeople1
            // 
            this.btnPeople1.AutoSize = true;
            this.btnPeople1.BackColor = System.Drawing.Color.DimGray;
            this.btnPeople1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPeople1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnPeople1.Location = new System.Drawing.Point(2418, 372);
            this.btnPeople1.Margin = new System.Windows.Forms.Padding(5);
            this.btnPeople1.Name = "btnPeople1";
            this.btnPeople1.Size = new System.Drawing.Size(405, 132);
            this.btnPeople1.TabIndex = 1;
            this.btnPeople1.Text = "Next >>";
            this.btnPeople1.UseVisualStyleBackColor = false;
            this.btnPeople1.Click += new System.EventHandler(this.btnPeople1_Click);
            // 
            // pbPeople1
            // 
            this.pbPeople1.Location = new System.Drawing.Point(432, 198);
            this.pbPeople1.Margin = new System.Windows.Forms.Padding(5);
            this.pbPeople1.Name = "pbPeople1";
            this.pbPeople1.Size = new System.Drawing.Size(409, 431);
            this.pbPeople1.TabIndex = 0;
            this.pbPeople1.TabStop = false;
            this.pbPeople1.Click += new System.EventHandler(this.pbPeople1_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.tabControl6);
            this.tabPage3.Controls.Add(this.label7);
            this.tabPage3.Controls.Add(this.label6);
            this.tabPage3.Controls.Add(this.label3);
            this.tabPage3.Controls.Add(this.rtbCareer2);
            this.tabPage3.Controls.Add(this.rtbCareer1);
            this.tabPage3.Controls.Add(this.lblCareer1);
            this.tabPage3.Location = new System.Drawing.Point(10, 62);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(5);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(5);
            this.tabPage3.Size = new System.Drawing.Size(3230, 1490);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Careers";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabControl6
            // 
            this.tabControl6.Controls.Add(this.tabPage26);
            this.tabControl6.Controls.Add(this.tabPage27);
            this.tabControl6.Controls.Add(this.tabPage28);
            this.tabControl6.Controls.Add(this.tabPage29);
            this.tabControl6.Location = new System.Drawing.Point(39, 666);
            this.tabControl6.Margin = new System.Windows.Forms.Padding(5);
            this.tabControl6.Name = "tabControl6";
            this.tabControl6.SelectedIndex = 0;
            this.tabControl6.Size = new System.Drawing.Size(3186, 829);
            this.tabControl6.TabIndex = 13;
            // 
            // tabPage26
            // 
            this.tabPage26.Controls.Add(this.label5);
            this.tabPage26.Controls.Add(this.label4);
            this.tabPage26.Controls.Add(this.lblCareer6);
            this.tabPage26.Controls.Add(this.lblCareer5);
            this.tabPage26.Controls.Add(this.lblCareer4);
            this.tabPage26.Controls.Add(this.lblCareer3);
            this.tabPage26.Controls.Add(this.lblCareer2);
            this.tabPage26.Location = new System.Drawing.Point(10, 62);
            this.tabPage26.Margin = new System.Windows.Forms.Padding(5);
            this.tabPage26.Name = "tabPage26";
            this.tabPage26.Padding = new System.Windows.Forms.Padding(5);
            this.tabPage26.Size = new System.Drawing.Size(3166, 757);
            this.tabPage26.TabIndex = 0;
            this.tabPage26.Text = "Career Statistics";
            this.tabPage26.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(1787, 400);
            this.label5.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(205, 56);
            this.label5.TabIndex = 17;
            this.label5.Text = "Careers";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(795, 400);
            this.label4.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(270, 56);
            this.label4.TabIndex = 16;
            this.label4.Text = "Employers";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblCareer6
            // 
            this.lblCareer6.AutoSize = true;
            this.lblCareer6.Location = new System.Drawing.Point(1721, 479);
            this.lblCareer6.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblCareer6.Name = "lblCareer6";
            this.lblCareer6.Size = new System.Drawing.Size(31, 45);
            this.lblCareer6.TabIndex = 15;
            this.lblCareer6.Text = " ";
            this.lblCareer6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCareer5
            // 
            this.lblCareer5.AutoSize = true;
            this.lblCareer5.Location = new System.Drawing.Point(729, 479);
            this.lblCareer5.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblCareer5.Name = "lblCareer5";
            this.lblCareer5.Size = new System.Drawing.Size(31, 45);
            this.lblCareer5.TabIndex = 14;
            this.lblCareer5.Text = " ";
            this.lblCareer5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCareer4
            // 
            this.lblCareer4.AutoSize = true;
            this.lblCareer4.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCareer4.Location = new System.Drawing.Point(626, 108);
            this.lblCareer4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblCareer4.Name = "lblCareer4";
            this.lblCareer4.Size = new System.Drawing.Size(152, 55);
            this.lblCareer4.TabIndex = 13;
            this.lblCareer4.Text = "label6";
            this.lblCareer4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCareer3
            // 
            this.lblCareer3.AutoSize = true;
            this.lblCareer3.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCareer3.Location = new System.Drawing.Point(626, 265);
            this.lblCareer3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblCareer3.Name = "lblCareer3";
            this.lblCareer3.Size = new System.Drawing.Size(152, 55);
            this.lblCareer3.TabIndex = 12;
            this.lblCareer3.Text = "label5";
            this.lblCareer3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCareer2
            // 
            this.lblCareer2.AutoSize = true;
            this.lblCareer2.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCareer2.Location = new System.Drawing.Point(949, 5);
            this.lblCareer2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblCareer2.Name = "lblCareer2";
            this.lblCareer2.Size = new System.Drawing.Size(152, 55);
            this.lblCareer2.TabIndex = 11;
            this.lblCareer2.Text = "label4";
            this.lblCareer2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabPage27
            // 
            this.tabPage27.Controls.Add(this.webBrowser1);
            this.tabPage27.Location = new System.Drawing.Point(10, 62);
            this.tabPage27.Margin = new System.Windows.Forms.Padding(5);
            this.tabPage27.Name = "tabPage27";
            this.tabPage27.Padding = new System.Windows.Forms.Padding(5);
            this.tabPage27.Size = new System.Drawing.Size(3166, 757);
            this.tabPage27.TabIndex = 1;
            this.tabPage27.Text = "Career Map";
            this.tabPage27.UseVisualStyleBackColor = true;
            // 
            // webBrowser1
            // 
            this.webBrowser1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowser1.Location = new System.Drawing.Point(5, 5);
            this.webBrowser1.Margin = new System.Windows.Forms.Padding(5);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(36, 31);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(3156, 747);
            this.webBrowser1.TabIndex = 0;
            this.webBrowser1.Url = new System.Uri("http://ist.rit.edu/api/map", System.UriKind.Absolute);
            // 
            // tabPage28
            // 
            this.tabPage28.Controls.Add(this.textBox4);
            this.tabPage28.Controls.Add(this.textBox3);
            this.tabPage28.Controls.Add(this.textBox2);
            this.tabPage28.Controls.Add(this.textBox1);
            this.tabPage28.Controls.Add(this.rtbTwo);
            this.tabPage28.Controls.Add(this.rtbThree);
            this.tabPage28.Controls.Add(this.rtbFour);
            this.tabPage28.Controls.Add(this.rtbOne);
            this.tabPage28.Location = new System.Drawing.Point(10, 62);
            this.tabPage28.Margin = new System.Windows.Forms.Padding(5);
            this.tabPage28.Name = "tabPage28";
            this.tabPage28.Padding = new System.Windows.Forms.Padding(5);
            this.tabPage28.Size = new System.Drawing.Size(3166, 757);
            this.tabPage28.TabIndex = 2;
            this.tabPage28.Text = "Co-op Table";
            this.tabPage28.UseVisualStyleBackColor = true;
            // 
            // tabPage29
            // 
            this.tabPage29.Controls.Add(this.textBox5);
            this.tabPage29.Controls.Add(this.textBox6);
            this.tabPage29.Controls.Add(this.textBox7);
            this.tabPage29.Controls.Add(this.textBox8);
            this.tabPage29.Controls.Add(this.rtb2);
            this.tabPage29.Controls.Add(this.rtb3);
            this.tabPage29.Controls.Add(this.rtb4);
            this.tabPage29.Controls.Add(this.rtb1);
            this.tabPage29.Location = new System.Drawing.Point(10, 62);
            this.tabPage29.Margin = new System.Windows.Forms.Padding(5);
            this.tabPage29.Name = "tabPage29";
            this.tabPage29.Padding = new System.Windows.Forms.Padding(5);
            this.tabPage29.Size = new System.Drawing.Size(3166, 757);
            this.tabPage29.TabIndex = 3;
            this.tabPage29.Text = "Career Table";
            this.tabPage29.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(2382, 212);
            this.label7.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(137, 45);
            this.label7.TabIndex = 12;
            this.label7.Text = "Co-Op";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(555, 212);
            this.label6.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(240, 45);
            this.label6.TabIndex = 11;
            this.label6.Text = "Employment";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(996, 456);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 55);
            this.label3.TabIndex = 3;
            // 
            // rtbCareer2
            // 
            this.rtbCareer2.BackColor = System.Drawing.SystemColors.Control;
            this.rtbCareer2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtbCareer2.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbCareer2.Location = new System.Drawing.Point(1657, 270);
            this.rtbCareer2.Margin = new System.Windows.Forms.Padding(5);
            this.rtbCareer2.Name = "rtbCareer2";
            this.rtbCareer2.Size = new System.Drawing.Size(1529, 355);
            this.rtbCareer2.TabIndex = 2;
            this.rtbCareer2.Text = "";
            // 
            // rtbCareer1
            // 
            this.rtbCareer1.BackColor = System.Drawing.SystemColors.Control;
            this.rtbCareer1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtbCareer1.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbCareer1.Location = new System.Drawing.Point(39, 270);
            this.rtbCareer1.Margin = new System.Windows.Forms.Padding(5);
            this.rtbCareer1.Name = "rtbCareer1";
            this.rtbCareer1.Size = new System.Drawing.Size(1550, 355);
            this.rtbCareer1.TabIndex = 1;
            this.rtbCareer1.Text = "";
            // 
            // lblCareer1
            // 
            this.lblCareer1.AutoSize = true;
            this.lblCareer1.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCareer1.Location = new System.Drawing.Point(747, 48);
            this.lblCareer1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblCareer1.Name = "lblCareer1";
            this.lblCareer1.Size = new System.Drawing.Size(215, 76);
            this.lblCareer1.TabIndex = 0;
            this.lblCareer1.Text = "label3";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.label10);
            this.tabPage4.Controls.Add(this.label9);
            this.tabPage4.Controls.Add(this.cbResearch2);
            this.tabPage4.Controls.Add(this.cbResearch1);
            this.tabPage4.Controls.Add(this.rtbResearch1);
            this.tabPage4.Location = new System.Drawing.Point(10, 62);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(5);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(5);
            this.tabPage4.Size = new System.Drawing.Size(3230, 1490);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Research";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(873, 139);
            this.label10.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(433, 45);
            this.label10.TabIndex = 6;
            this.label10.Text = "Find Research By Topic";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(11, 139);
            this.label9.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(467, 45);
            this.label9.TabIndex = 5;
            this.label9.Text = "Find Research By Faculty";
            // 
            // cbResearch2
            // 
            this.cbResearch2.FormattingEnabled = true;
            this.cbResearch2.Location = new System.Drawing.Point(882, 265);
            this.cbResearch2.Margin = new System.Windows.Forms.Padding(5);
            this.cbResearch2.Name = "cbResearch2";
            this.cbResearch2.Size = new System.Drawing.Size(710, 53);
            this.cbResearch2.TabIndex = 4;
            this.cbResearch2.SelectedIndexChanged += new System.EventHandler(this.cbResearch2_SelectedIndexChanged);
            // 
            // cbResearch1
            // 
            this.cbResearch1.FormattingEnabled = true;
            this.cbResearch1.Location = new System.Drawing.Point(11, 265);
            this.cbResearch1.Margin = new System.Windows.Forms.Padding(5);
            this.cbResearch1.Name = "cbResearch1";
            this.cbResearch1.Size = new System.Drawing.Size(710, 53);
            this.cbResearch1.TabIndex = 3;
            this.cbResearch1.SelectedIndexChanged += new System.EventHandler(this.cbResearch1_SelectedIndexChanged_1);
            // 
            // rtbResearch1
            // 
            this.rtbResearch1.Location = new System.Drawing.Point(11, 432);
            this.rtbResearch1.Margin = new System.Windows.Forms.Padding(5);
            this.rtbResearch1.Name = "rtbResearch1";
            this.rtbResearch1.Size = new System.Drawing.Size(3211, 1056);
            this.rtbResearch1.TabIndex = 2;
            this.rtbResearch1.Text = "";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.richTextBox2);
            this.tabPage5.Controls.Add(this.tabControl2);
            this.tabPage5.Location = new System.Drawing.Point(10, 62);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(5);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(5);
            this.tabPage5.Size = new System.Drawing.Size(3230, 1490);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Student Resources";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // richTextBox2
            // 
            this.richTextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox2.Location = new System.Drawing.Point(1255, 36);
            this.richTextBox2.Margin = new System.Windows.Forms.Padding(5);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.ReadOnly = true;
            this.richTextBox2.Size = new System.Drawing.Size(533, 70);
            this.richTextBox2.TabIndex = 1;
            this.richTextBox2.Text = "Student Resources";
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage7);
            this.tabControl2.Controls.Add(this.tabPage8);
            this.tabControl2.Controls.Add(this.tabPage9);
            this.tabControl2.Controls.Add(this.tabPage10);
            this.tabControl2.Controls.Add(this.tabPage11);
            this.tabControl2.Controls.Add(this.tabPage12);
            this.tabControl2.Controls.Add(this.tabPage13);
            this.tabControl2.Location = new System.Drawing.Point(0, 112);
            this.tabControl2.Margin = new System.Windows.Forms.Padding(5);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(3218, 1403);
            this.tabControl2.TabIndex = 0;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.pbAmbassador1);
            this.tabPage7.Controls.Add(this.rtbAmbassador1);
            this.tabPage7.Controls.Add(this.lblAmbassador1);
            this.tabPage7.Location = new System.Drawing.Point(10, 62);
            this.tabPage7.Margin = new System.Windows.Forms.Padding(5);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(5);
            this.tabPage7.Size = new System.Drawing.Size(3198, 1331);
            this.tabPage7.TabIndex = 0;
            this.tabPage7.Text = "Student Ambassadors";
            this.tabPage7.UseVisualStyleBackColor = true;
            this.tabPage7.Click += new System.EventHandler(this.tabPage7_Click);
            // 
            // pbAmbassador1
            // 
            this.pbAmbassador1.Location = new System.Drawing.Point(1020, 155);
            this.pbAmbassador1.Margin = new System.Windows.Forms.Padding(5);
            this.pbAmbassador1.Name = "pbAmbassador1";
            this.pbAmbassador1.Size = new System.Drawing.Size(967, 437);
            this.pbAmbassador1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbAmbassador1.TabIndex = 2;
            this.pbAmbassador1.TabStop = false;
            // 
            // rtbAmbassador1
            // 
            this.rtbAmbassador1.Location = new System.Drawing.Point(50, 601);
            this.rtbAmbassador1.Margin = new System.Windows.Forms.Padding(5);
            this.rtbAmbassador1.Name = "rtbAmbassador1";
            this.rtbAmbassador1.Size = new System.Drawing.Size(3129, 712);
            this.rtbAmbassador1.TabIndex = 1;
            this.rtbAmbassador1.Text = "";
            // 
            // lblAmbassador1
            // 
            this.lblAmbassador1.AutoSize = true;
            this.lblAmbassador1.Location = new System.Drawing.Point(1070, 71);
            this.lblAmbassador1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblAmbassador1.Name = "lblAmbassador1";
            this.lblAmbassador1.Size = new System.Drawing.Size(124, 45);
            this.lblAmbassador1.TabIndex = 0;
            this.lblAmbassador1.Text = "label3";
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.lblAbroad2);
            this.tabPage8.Controls.Add(this.lblAbroad1);
            this.tabPage8.Controls.Add(this.rtbAbroad2);
            this.tabPage8.Controls.Add(this.rtbAbroad1);
            this.tabPage8.Controls.Add(this.rtbAbroad);
            this.tabPage8.Controls.Add(this.richTextBox3);
            this.tabPage8.Location = new System.Drawing.Point(10, 62);
            this.tabPage8.Margin = new System.Windows.Forms.Padding(5);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(5);
            this.tabPage8.Size = new System.Drawing.Size(3198, 1331);
            this.tabPage8.TabIndex = 1;
            this.tabPage8.Text = "Study Abroad";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // lblAbroad2
            // 
            this.lblAbroad2.AutoSize = true;
            this.lblAbroad2.Location = new System.Drawing.Point(1803, 601);
            this.lblAbroad2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblAbroad2.Name = "lblAbroad2";
            this.lblAbroad2.Size = new System.Drawing.Size(124, 45);
            this.lblAbroad2.TabIndex = 6;
            this.lblAbroad2.Text = "label3";
            // 
            // lblAbroad1
            // 
            this.lblAbroad1.AutoSize = true;
            this.lblAbroad1.Location = new System.Drawing.Point(420, 601);
            this.lblAbroad1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblAbroad1.Name = "lblAbroad1";
            this.lblAbroad1.Size = new System.Drawing.Size(124, 45);
            this.lblAbroad1.TabIndex = 5;
            this.lblAbroad1.Text = "label1";
            // 
            // rtbAbroad2
            // 
            this.rtbAbroad2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtbAbroad2.Location = new System.Drawing.Point(1810, 747);
            this.rtbAbroad2.Margin = new System.Windows.Forms.Padding(5);
            this.rtbAbroad2.Name = "rtbAbroad2";
            this.rtbAbroad2.Size = new System.Drawing.Size(1019, 465);
            this.rtbAbroad2.TabIndex = 3;
            this.rtbAbroad2.Text = "";
            this.rtbAbroad2.TextChanged += new System.EventHandler(this.rtbAbroad2_TextChanged);
            // 
            // rtbAbroad1
            // 
            this.rtbAbroad1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtbAbroad1.Location = new System.Drawing.Point(427, 747);
            this.rtbAbroad1.Margin = new System.Windows.Forms.Padding(5);
            this.rtbAbroad1.Name = "rtbAbroad1";
            this.rtbAbroad1.Size = new System.Drawing.Size(1019, 465);
            this.rtbAbroad1.TabIndex = 2;
            this.rtbAbroad1.Text = "";
            this.rtbAbroad1.TextChanged += new System.EventHandler(this.rtbAbroad1_TextChanged);
            // 
            // rtbAbroad
            // 
            this.rtbAbroad.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtbAbroad.Location = new System.Drawing.Point(292, 240);
            this.rtbAbroad.Margin = new System.Windows.Forms.Padding(5);
            this.rtbAbroad.Name = "rtbAbroad";
            this.rtbAbroad.Size = new System.Drawing.Size(2695, 203);
            this.rtbAbroad.TabIndex = 1;
            this.rtbAbroad.Text = "";
            // 
            // richTextBox3
            // 
            this.richTextBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox3.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox3.Location = new System.Drawing.Point(1319, 81);
            this.richTextBox3.Margin = new System.Windows.Forms.Padding(5);
            this.richTextBox3.Name = "richTextBox3";
            this.richTextBox3.Size = new System.Drawing.Size(754, 85);
            this.richTextBox3.TabIndex = 0;
            this.richTextBox3.Text = "Study Abroad";
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.tabControl4);
            this.tabPage9.Location = new System.Drawing.Point(10, 62);
            this.tabPage9.Margin = new System.Windows.Forms.Padding(5);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(5);
            this.tabPage9.Size = new System.Drawing.Size(3198, 1331);
            this.tabPage9.TabIndex = 2;
            this.tabPage9.Text = " Student Services";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // tabControl4
            // 
            this.tabControl4.Appearance = System.Windows.Forms.TabAppearance.Buttons;
            this.tabControl4.Controls.Add(this.tabPage22);
            this.tabControl4.Controls.Add(this.tabPage24);
            this.tabControl4.Location = new System.Drawing.Point(14, 12);
            this.tabControl4.Margin = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.tabControl4.Name = "tabControl4";
            this.tabControl4.SelectedIndex = 0;
            this.tabControl4.Size = new System.Drawing.Size(3172, 1310);
            this.tabControl4.TabIndex = 13;
            // 
            // tabPage22
            // 
            this.tabPage22.Controls.Add(this.lblServices2);
            this.tabPage22.Controls.Add(this.linkServices1);
            this.tabPage22.Controls.Add(this.rtbServices2);
            this.tabPage22.Controls.Add(this.rtbServices1);
            this.tabPage22.Location = new System.Drawing.Point(4, 57);
            this.tabPage22.Margin = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.tabPage22.Name = "tabPage22";
            this.tabPage22.Padding = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.tabPage22.Size = new System.Drawing.Size(3164, 1249);
            this.tabPage22.TabIndex = 0;
            this.tabPage22.Text = "Professional Advising";
            this.tabPage22.UseVisualStyleBackColor = true;
            // 
            // lblServices2
            // 
            this.lblServices2.AutoSize = true;
            this.lblServices2.Location = new System.Drawing.Point(1340, 716);
            this.lblServices2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblServices2.Name = "lblServices2";
            this.lblServices2.Size = new System.Drawing.Size(124, 45);
            this.lblServices2.TabIndex = 10;
            this.lblServices2.Text = "label3";
            // 
            // linkServices1
            // 
            this.linkServices1.AutoSize = true;
            this.linkServices1.Location = new System.Drawing.Point(679, 577);
            this.linkServices1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.linkServices1.Name = "linkServices1";
            this.linkServices1.Size = new System.Drawing.Size(100, 45);
            this.linkServices1.TabIndex = 6;
            this.linkServices1.TabStop = true;
            this.linkServices1.Text = "FAQ";
            this.linkServices1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkServices1_LinkClicked);
            // 
            // rtbServices2
            // 
            this.rtbServices2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtbServices2.Location = new System.Drawing.Point(485, 794);
            this.rtbServices2.Margin = new System.Windows.Forms.Padding(5);
            this.rtbServices2.Name = "rtbServices2";
            this.rtbServices2.Size = new System.Drawing.Size(2012, 363);
            this.rtbServices2.TabIndex = 7;
            this.rtbServices2.Text = "";
            this.rtbServices2.TextChanged += new System.EventHandler(this.rtbServices2_TextChanged);
            // 
            // rtbServices1
            // 
            this.rtbServices1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtbServices1.Location = new System.Drawing.Point(165, 12);
            this.rtbServices1.Margin = new System.Windows.Forms.Padding(5);
            this.rtbServices1.Name = "rtbServices1";
            this.rtbServices1.Size = new System.Drawing.Size(2800, 442);
            this.rtbServices1.TabIndex = 1;
            this.rtbServices1.Text = "";
            // 
            // tabPage24
            // 
            this.tabPage24.Controls.Add(this.lblServices4);
            this.tabPage24.Controls.Add(this.rtbServices4);
            this.tabPage24.Location = new System.Drawing.Point(4, 57);
            this.tabPage24.Margin = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.tabPage24.Name = "tabPage24";
            this.tabPage24.Padding = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.tabPage24.Size = new System.Drawing.Size(3164, 1249);
            this.tabPage24.TabIndex = 2;
            this.tabPage24.Text = "Minor Advising";
            this.tabPage24.UseVisualStyleBackColor = true;
            // 
            // lblServices4
            // 
            this.lblServices4.AutoSize = true;
            this.lblServices4.Location = new System.Drawing.Point(1116, 59);
            this.lblServices4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblServices4.Name = "lblServices4";
            this.lblServices4.Size = new System.Drawing.Size(124, 45);
            this.lblServices4.TabIndex = 12;
            this.lblServices4.Text = "label5";
            this.lblServices4.Click += new System.EventHandler(this.lblServices4_Click);
            // 
            // rtbServices4
            // 
            this.rtbServices4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtbServices4.Location = new System.Drawing.Point(85, 195);
            this.rtbServices4.Margin = new System.Windows.Forms.Padding(5);
            this.rtbServices4.Name = "rtbServices4";
            this.rtbServices4.Size = new System.Drawing.Size(2976, 849);
            this.rtbServices4.TabIndex = 8;
            this.rtbServices4.Text = "";
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.linkLab1);
            this.tabPage10.Controls.Add(this.rtbLab1);
            this.tabPage10.Controls.Add(this.lblLab1);
            this.tabPage10.Location = new System.Drawing.Point(10, 62);
            this.tabPage10.Margin = new System.Windows.Forms.Padding(5);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(5);
            this.tabPage10.Size = new System.Drawing.Size(3198, 1331);
            this.tabPage10.TabIndex = 3;
            this.tabPage10.Text = "Lab Info";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // linkLab1
            // 
            this.linkLab1.AutoSize = true;
            this.linkLab1.Location = new System.Drawing.Point(1243, 701);
            this.linkLab1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.linkLab1.Name = "linkLab1";
            this.linkLab1.Size = new System.Drawing.Size(124, 45);
            this.linkLab1.TabIndex = 2;
            this.linkLab1.Text = "label3";
            // 
            // rtbLab1
            // 
            this.rtbLab1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtbLab1.Location = new System.Drawing.Point(274, 274);
            this.rtbLab1.Margin = new System.Windows.Forms.Padding(5);
            this.rtbLab1.Name = "rtbLab1";
            this.rtbLab1.Size = new System.Drawing.Size(2652, 307);
            this.rtbLab1.TabIndex = 1;
            this.rtbLab1.Text = "";
            // 
            // lblLab1
            // 
            this.lblLab1.AutoSize = true;
            this.lblLab1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLab1.Location = new System.Drawing.Point(1237, 133);
            this.lblLab1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblLab1.Name = "lblLab1";
            this.lblLab1.Size = new System.Drawing.Size(187, 67);
            this.lblLab1.TabIndex = 0;
            this.lblLab1.Text = "label3";
            // 
            // tabPage11
            // 
            this.tabPage11.Controls.Add(this.gbForms2);
            this.tabPage11.Controls.Add(this.gbForms1);
            this.tabPage11.Location = new System.Drawing.Point(10, 62);
            this.tabPage11.Margin = new System.Windows.Forms.Padding(5);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(5);
            this.tabPage11.Size = new System.Drawing.Size(3198, 1331);
            this.tabPage11.TabIndex = 4;
            this.tabPage11.Text = "Forms";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // gbForms2
            // 
            this.gbForms2.Controls.Add(this.rtbForms2);
            this.gbForms2.Location = new System.Drawing.Point(197, 766);
            this.gbForms2.Margin = new System.Windows.Forms.Padding(5);
            this.gbForms2.Name = "gbForms2";
            this.gbForms2.Padding = new System.Windows.Forms.Padding(5);
            this.gbForms2.Size = new System.Drawing.Size(2823, 364);
            this.gbForms2.TabIndex = 1;
            this.gbForms2.TabStop = false;
            this.gbForms2.Text = "groupBox2";
            // 
            // rtbForms2
            // 
            this.rtbForms2.Location = new System.Drawing.Point(25, 54);
            this.rtbForms2.Margin = new System.Windows.Forms.Padding(5);
            this.rtbForms2.Name = "rtbForms2";
            this.rtbForms2.Size = new System.Drawing.Size(2751, 295);
            this.rtbForms2.TabIndex = 1;
            this.rtbForms2.Text = "";
            this.rtbForms2.TextChanged += new System.EventHandler(this.rtbForms2_TextChanged);
            // 
            // gbForms1
            // 
            this.gbForms1.Controls.Add(this.rtbForms1);
            this.gbForms1.Location = new System.Drawing.Point(197, 88);
            this.gbForms1.Margin = new System.Windows.Forms.Padding(5);
            this.gbForms1.Name = "gbForms1";
            this.gbForms1.Padding = new System.Windows.Forms.Padding(5);
            this.gbForms1.Size = new System.Drawing.Size(2823, 611);
            this.gbForms1.TabIndex = 0;
            this.gbForms1.TabStop = false;
            this.gbForms1.Text = "groupBox1";
            // 
            // rtbForms1
            // 
            this.rtbForms1.Location = new System.Drawing.Point(25, 70);
            this.rtbForms1.Margin = new System.Windows.Forms.Padding(5);
            this.rtbForms1.Name = "rtbForms1";
            this.rtbForms1.Size = new System.Drawing.Size(2751, 503);
            this.rtbForms1.TabIndex = 0;
            this.rtbForms1.Text = "";
            // 
            // tabPage12
            // 
            this.tabPage12.Controls.Add(this.rtbCoop1);
            this.tabPage12.Controls.Add(this.lblCoop1);
            this.tabPage12.Location = new System.Drawing.Point(10, 62);
            this.tabPage12.Margin = new System.Windows.Forms.Padding(5);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Padding = new System.Windows.Forms.Padding(5);
            this.tabPage12.Size = new System.Drawing.Size(3198, 1331);
            this.tabPage12.TabIndex = 5;
            this.tabPage12.Text = " Co-op Enrollment";
            this.tabPage12.UseVisualStyleBackColor = true;
            // 
            // rtbCoop1
            // 
            this.rtbCoop1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtbCoop1.Location = new System.Drawing.Point(92, 208);
            this.rtbCoop1.Margin = new System.Windows.Forms.Padding(5);
            this.rtbCoop1.Name = "rtbCoop1";
            this.rtbCoop1.Size = new System.Drawing.Size(3022, 1057);
            this.rtbCoop1.TabIndex = 1;
            this.rtbCoop1.Text = "";
            // 
            // lblCoop1
            // 
            this.lblCoop1.AutoSize = true;
            this.lblCoop1.Location = new System.Drawing.Point(1237, 127);
            this.lblCoop1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblCoop1.Name = "lblCoop1";
            this.lblCoop1.Size = new System.Drawing.Size(124, 45);
            this.lblCoop1.TabIndex = 0;
            this.lblCoop1.Text = "label3";
            // 
            // tabPage13
            // 
            this.tabPage13.Controls.Add(this.rtbNews2);
            this.tabPage13.Controls.Add(this.rtbNews1);
            this.tabPage13.Controls.Add(this.lblNews2);
            this.tabPage13.Controls.Add(this.lblNews1);
            this.tabPage13.Location = new System.Drawing.Point(10, 62);
            this.tabPage13.Margin = new System.Windows.Forms.Padding(5);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Padding = new System.Windows.Forms.Padding(5);
            this.tabPage13.Size = new System.Drawing.Size(3198, 1331);
            this.tabPage13.TabIndex = 6;
            this.tabPage13.Text = "News";
            this.tabPage13.UseVisualStyleBackColor = true;
            this.tabPage13.Click += new System.EventHandler(this.tabPage13_Click);
            // 
            // rtbNews2
            // 
            this.rtbNews2.Location = new System.Drawing.Point(36, 637);
            this.rtbNews2.Margin = new System.Windows.Forms.Padding(5);
            this.rtbNews2.Name = "rtbNews2";
            this.rtbNews2.Size = new System.Drawing.Size(3145, 660);
            this.rtbNews2.TabIndex = 3;
            this.rtbNews2.Text = "";
            // 
            // rtbNews1
            // 
            this.rtbNews1.Location = new System.Drawing.Point(36, 205);
            this.rtbNews1.Margin = new System.Windows.Forms.Padding(5);
            this.rtbNews1.Name = "rtbNews1";
            this.rtbNews1.Size = new System.Drawing.Size(3145, 249);
            this.rtbNews1.TabIndex = 2;
            this.rtbNews1.Text = "";
            // 
            // lblNews2
            // 
            this.lblNews2.AutoSize = true;
            this.lblNews2.Location = new System.Drawing.Point(1287, 550);
            this.lblNews2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblNews2.Name = "lblNews2";
            this.lblNews2.Size = new System.Drawing.Size(209, 45);
            this.lblNews2.TabIndex = 1;
            this.lblNews2.Text = "Past News";
            // 
            // lblNews1
            // 
            this.lblNews1.AutoSize = true;
            this.lblNews1.Location = new System.Drawing.Point(1280, 101);
            this.lblNews1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblNews1.Name = "lblNews1";
            this.lblNews1.Size = new System.Drawing.Size(255, 45);
            this.lblNews1.TabIndex = 0;
            this.lblNews1.Text = "Recent News";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.label8);
            this.tabPage6.Controls.Add(this.label1);
            this.tabPage6.Controls.Add(this.tabControl5);
            this.tabPage6.Controls.Add(this.tabControl3);
            this.tabPage6.Location = new System.Drawing.Point(10, 62);
            this.tabPage6.Margin = new System.Windows.Forms.Padding(5);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(5);
            this.tabPage6.Size = new System.Drawing.Size(3230, 1490);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Majors/Minors";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(1465, 801);
            this.label8.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(136, 45);
            this.label8.TabIndex = 5;
            this.label8.Text = "Minors";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1465, 23);
            this.label1.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(139, 45);
            this.label1.TabIndex = 4;
            this.label1.Text = "Majors";
            // 
            // tabControl5
            // 
            this.tabControl5.Controls.Add(this.tabPage23);
            this.tabControl5.Controls.Add(this.tabPage25);
            this.tabControl5.Location = new System.Drawing.Point(21, 73);
            this.tabControl5.Margin = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.tabControl5.Name = "tabControl5";
            this.tabControl5.SelectedIndex = 0;
            this.tabControl5.Size = new System.Drawing.Size(3195, 721);
            this.tabControl5.TabIndex = 3;
            // 
            // tabPage23
            // 
            this.tabPage23.Controls.Add(this.rtbDegree2);
            this.tabPage23.Location = new System.Drawing.Point(10, 62);
            this.tabPage23.Margin = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.tabPage23.Name = "tabPage23";
            this.tabPage23.Padding = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.tabPage23.Size = new System.Drawing.Size(3175, 649);
            this.tabPage23.TabIndex = 0;
            this.tabPage23.Text = "Graduate";
            this.tabPage23.UseVisualStyleBackColor = true;
            // 
            // rtbDegree2
            // 
            this.rtbDegree2.Location = new System.Drawing.Point(14, 12);
            this.rtbDegree2.Margin = new System.Windows.Forms.Padding(5);
            this.rtbDegree2.Name = "rtbDegree2";
            this.rtbDegree2.Size = new System.Drawing.Size(3140, 616);
            this.rtbDegree2.TabIndex = 1;
            this.rtbDegree2.Text = "";
            // 
            // tabPage25
            // 
            this.tabPage25.Controls.Add(this.rtbDegree1);
            this.tabPage25.Location = new System.Drawing.Point(10, 62);
            this.tabPage25.Margin = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.tabPage25.Name = "tabPage25";
            this.tabPage25.Padding = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.tabPage25.Size = new System.Drawing.Size(3175, 649);
            this.tabPage25.TabIndex = 1;
            this.tabPage25.Text = "Undergraduate";
            this.tabPage25.UseVisualStyleBackColor = true;
            // 
            // rtbDegree1
            // 
            this.rtbDegree1.Location = new System.Drawing.Point(14, 12);
            this.rtbDegree1.Margin = new System.Windows.Forms.Padding(5);
            this.rtbDegree1.Name = "rtbDegree1";
            this.rtbDegree1.Size = new System.Drawing.Size(3140, 616);
            this.rtbDegree1.TabIndex = 0;
            this.rtbDegree1.Text = "";
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage15);
            this.tabControl3.Controls.Add(this.tabPage14);
            this.tabControl3.Controls.Add(this.tabPage16);
            this.tabControl3.Controls.Add(this.tabPage17);
            this.tabControl3.Controls.Add(this.tabPage18);
            this.tabControl3.Controls.Add(this.tabPage19);
            this.tabControl3.Controls.Add(this.tabPage20);
            this.tabControl3.Controls.Add(this.tabPage21);
            this.tabControl3.Location = new System.Drawing.Point(21, 859);
            this.tabControl3.Margin = new System.Windows.Forms.Padding(5);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(3196, 620);
            this.tabControl3.TabIndex = 2;
            // 
            // tabPage15
            // 
            this.tabPage15.Controls.Add(this.rtbDegree3);
            this.tabPage15.Location = new System.Drawing.Point(10, 62);
            this.tabPage15.Margin = new System.Windows.Forms.Padding(5);
            this.tabPage15.Name = "tabPage15";
            this.tabPage15.Padding = new System.Windows.Forms.Padding(5);
            this.tabPage15.Size = new System.Drawing.Size(3176, 548);
            this.tabPage15.TabIndex = 1;
            this.tabPage15.Text = "DBDDI-MN";
            this.tabPage15.UseVisualStyleBackColor = true;
            // 
            // rtbDegree3
            // 
            this.rtbDegree3.Location = new System.Drawing.Point(14, 12);
            this.rtbDegree3.Margin = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.rtbDegree3.Name = "rtbDegree3";
            this.rtbDegree3.Size = new System.Drawing.Size(3140, 517);
            this.rtbDegree3.TabIndex = 1;
            this.rtbDegree3.Text = "";
            // 
            // tabPage14
            // 
            this.tabPage14.Controls.Add(this.rtbDegree4);
            this.tabPage14.Location = new System.Drawing.Point(10, 62);
            this.tabPage14.Margin = new System.Windows.Forms.Padding(5);
            this.tabPage14.Name = "tabPage14";
            this.tabPage14.Padding = new System.Windows.Forms.Padding(5);
            this.tabPage14.Size = new System.Drawing.Size(3176, 548);
            this.tabPage14.TabIndex = 2;
            this.tabPage14.Text = "GIS-MN";
            this.tabPage14.UseVisualStyleBackColor = true;
            // 
            // rtbDegree4
            // 
            this.rtbDegree4.Location = new System.Drawing.Point(7, 12);
            this.rtbDegree4.Margin = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.rtbDegree4.Name = "rtbDegree4";
            this.rtbDegree4.Size = new System.Drawing.Size(3140, 517);
            this.rtbDegree4.TabIndex = 2;
            this.rtbDegree4.Text = "";
            // 
            // tabPage16
            // 
            this.tabPage16.Controls.Add(this.rtbDegree5);
            this.tabPage16.Location = new System.Drawing.Point(10, 62);
            this.tabPage16.Margin = new System.Windows.Forms.Padding(5);
            this.tabPage16.Name = "tabPage16";
            this.tabPage16.Padding = new System.Windows.Forms.Padding(5);
            this.tabPage16.Size = new System.Drawing.Size(3176, 548);
            this.tabPage16.TabIndex = 3;
            this.tabPage16.Text = "MEDINFO-MN";
            this.tabPage16.UseVisualStyleBackColor = true;
            // 
            // rtbDegree5
            // 
            this.rtbDegree5.Location = new System.Drawing.Point(14, 12);
            this.rtbDegree5.Margin = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.rtbDegree5.Name = "rtbDegree5";
            this.rtbDegree5.Size = new System.Drawing.Size(3140, 517);
            this.rtbDegree5.TabIndex = 2;
            this.rtbDegree5.Text = "";
            // 
            // tabPage17
            // 
            this.tabPage17.Controls.Add(this.rtbDegree6);
            this.tabPage17.Location = new System.Drawing.Point(10, 62);
            this.tabPage17.Margin = new System.Windows.Forms.Padding(5);
            this.tabPage17.Name = "tabPage17";
            this.tabPage17.Padding = new System.Windows.Forms.Padding(5);
            this.tabPage17.Size = new System.Drawing.Size(3176, 548);
            this.tabPage17.TabIndex = 4;
            this.tabPage17.Text = "MDDEV-MN";
            this.tabPage17.UseVisualStyleBackColor = true;
            // 
            // rtbDegree6
            // 
            this.rtbDegree6.Location = new System.Drawing.Point(14, 12);
            this.rtbDegree6.Margin = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.rtbDegree6.Name = "rtbDegree6";
            this.rtbDegree6.Size = new System.Drawing.Size(3140, 517);
            this.rtbDegree6.TabIndex = 2;
            this.rtbDegree6.Text = "";
            // 
            // tabPage18
            // 
            this.tabPage18.Controls.Add(this.rtbDegree7);
            this.tabPage18.Location = new System.Drawing.Point(10, 62);
            this.tabPage18.Margin = new System.Windows.Forms.Padding(5);
            this.tabPage18.Name = "tabPage18";
            this.tabPage18.Padding = new System.Windows.Forms.Padding(5);
            this.tabPage18.Size = new System.Drawing.Size(3176, 548);
            this.tabPage18.TabIndex = 5;
            this.tabPage18.Text = "MDEV-MN";
            this.tabPage18.UseVisualStyleBackColor = true;
            // 
            // rtbDegree7
            // 
            this.rtbDegree7.Location = new System.Drawing.Point(14, 12);
            this.rtbDegree7.Margin = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.rtbDegree7.Name = "rtbDegree7";
            this.rtbDegree7.Size = new System.Drawing.Size(3140, 517);
            this.rtbDegree7.TabIndex = 2;
            this.rtbDegree7.Text = "";
            // 
            // tabPage19
            // 
            this.tabPage19.Controls.Add(this.rtbDegree8);
            this.tabPage19.Location = new System.Drawing.Point(10, 62);
            this.tabPage19.Margin = new System.Windows.Forms.Padding(5);
            this.tabPage19.Name = "tabPage19";
            this.tabPage19.Padding = new System.Windows.Forms.Padding(5);
            this.tabPage19.Size = new System.Drawing.Size(3176, 548);
            this.tabPage19.TabIndex = 6;
            this.tabPage19.Text = "NETSYS-MN";
            this.tabPage19.UseVisualStyleBackColor = true;
            // 
            // rtbDegree8
            // 
            this.rtbDegree8.Location = new System.Drawing.Point(14, 12);
            this.rtbDegree8.Margin = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.rtbDegree8.Name = "rtbDegree8";
            this.rtbDegree8.Size = new System.Drawing.Size(3140, 517);
            this.rtbDegree8.TabIndex = 2;
            this.rtbDegree8.Text = "";
            // 
            // tabPage20
            // 
            this.tabPage20.Controls.Add(this.rtbDegree9);
            this.tabPage20.Location = new System.Drawing.Point(10, 62);
            this.tabPage20.Margin = new System.Windows.Forms.Padding(5);
            this.tabPage20.Name = "tabPage20";
            this.tabPage20.Padding = new System.Windows.Forms.Padding(5);
            this.tabPage20.Size = new System.Drawing.Size(3176, 548);
            this.tabPage20.TabIndex = 7;
            this.tabPage20.Text = "WEBDD-MN";
            this.tabPage20.UseVisualStyleBackColor = true;
            // 
            // rtbDegree9
            // 
            this.rtbDegree9.Location = new System.Drawing.Point(14, 12);
            this.rtbDegree9.Margin = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.rtbDegree9.Name = "rtbDegree9";
            this.rtbDegree9.Size = new System.Drawing.Size(3140, 517);
            this.rtbDegree9.TabIndex = 2;
            this.rtbDegree9.Text = "";
            // 
            // tabPage21
            // 
            this.tabPage21.Controls.Add(this.rtbDegree10);
            this.tabPage21.Location = new System.Drawing.Point(10, 62);
            this.tabPage21.Margin = new System.Windows.Forms.Padding(5);
            this.tabPage21.Name = "tabPage21";
            this.tabPage21.Padding = new System.Windows.Forms.Padding(5);
            this.tabPage21.Size = new System.Drawing.Size(3176, 548);
            this.tabPage21.TabIndex = 8;
            this.tabPage21.Text = "WEBD-MN";
            this.tabPage21.UseVisualStyleBackColor = true;
            // 
            // rtbDegree10
            // 
            this.rtbDegree10.Location = new System.Drawing.Point(14, 12);
            this.rtbDegree10.Margin = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.rtbDegree10.Name = "rtbDegree10";
            this.rtbDegree10.Size = new System.Drawing.Size(3140, 517);
            this.rtbDegree10.TabIndex = 2;
            this.rtbDegree10.Text = "";
            // 
            // tabPage30
            // 
            this.tabPage30.Controls.Add(this.webBrowser2);
            this.tabPage30.Location = new System.Drawing.Point(10, 62);
            this.tabPage30.Margin = new System.Windows.Forms.Padding(5);
            this.tabPage30.Name = "tabPage30";
            this.tabPage30.Padding = new System.Windows.Forms.Padding(5);
            this.tabPage30.Size = new System.Drawing.Size(3230, 1490);
            this.tabPage30.TabIndex = 6;
            this.tabPage30.Text = "More Info";
            this.tabPage30.UseVisualStyleBackColor = true;
            // 
            // rtbOne
            // 
            this.rtbOne.Location = new System.Drawing.Point(308, 8);
            this.rtbOne.Name = "rtbOne";
            this.rtbOne.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.rtbOne.Size = new System.Drawing.Size(456, 720);
            this.rtbOne.TabIndex = 0;
            this.rtbOne.Text = "";
            // 
            // rtbFour
            // 
            this.rtbFour.Location = new System.Drawing.Point(1698, 8);
            this.rtbFour.Name = "rtbFour";
            this.rtbFour.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.rtbFour.Size = new System.Drawing.Size(458, 720);
            this.rtbFour.TabIndex = 2;
            this.rtbFour.Text = "";
            // 
            // rtbThree
            // 
            this.rtbThree.Location = new System.Drawing.Point(1234, 8);
            this.rtbThree.Name = "rtbThree";
            this.rtbThree.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.rtbThree.Size = new System.Drawing.Size(458, 720);
            this.rtbThree.TabIndex = 3;
            this.rtbThree.Text = "";
            // 
            // rtbTwo
            // 
            this.rtbTwo.Location = new System.Drawing.Point(770, 8);
            this.rtbTwo.Name = "rtbTwo";
            this.rtbTwo.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.rtbTwo.Size = new System.Drawing.Size(458, 720);
            this.rtbTwo.TabIndex = 4;
            this.rtbTwo.Text = "";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(308, 18);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(460, 53);
            this.textBox1.TabIndex = 5;
            this.textBox1.Text = "Company";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(1698, 18);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(460, 53);
            this.textBox2.TabIndex = 6;
            this.textBox2.Text = "Term";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(1232, 18);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(460, 53);
            this.textBox3.TabIndex = 7;
            this.textBox3.Text = "City";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(774, 18);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(460, 53);
            this.textBox4.TabIndex = 8;
            this.textBox4.Text = "Degree";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(892, 39);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(460, 53);
            this.textBox5.TabIndex = 16;
            this.textBox5.Text = "Degree";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(1350, 39);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(460, 53);
            this.textBox6.TabIndex = 15;
            this.textBox6.Text = "City";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(1816, 39);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(460, 53);
            this.textBox7.TabIndex = 14;
            this.textBox7.Text = "Title";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(426, 39);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(460, 53);
            this.textBox8.TabIndex = 13;
            this.textBox8.Text = "Company";
            // 
            // rtb2
            // 
            this.rtb2.Location = new System.Drawing.Point(888, 29);
            this.rtb2.Name = "rtb2";
            this.rtb2.ReadOnly = true;
            this.rtb2.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.rtb2.Size = new System.Drawing.Size(458, 720);
            this.rtb2.TabIndex = 12;
            this.rtb2.Text = "";
            // 
            // rtb3
            // 
            this.rtb3.Location = new System.Drawing.Point(1352, 29);
            this.rtb3.Name = "rtb3";
            this.rtb3.ReadOnly = true;
            this.rtb3.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.rtb3.Size = new System.Drawing.Size(458, 720);
            this.rtb3.TabIndex = 11;
            this.rtb3.Text = "";
            // 
            // rtb4
            // 
            this.rtb4.Location = new System.Drawing.Point(1816, 29);
            this.rtb4.Name = "rtb4";
            this.rtb4.ReadOnly = true;
            this.rtb4.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.rtb4.Size = new System.Drawing.Size(458, 720);
            this.rtb4.TabIndex = 10;
            this.rtb4.Text = "";
            // 
            // rtb1
            // 
            this.rtb1.Location = new System.Drawing.Point(426, 29);
            this.rtb1.Name = "rtb1";
            this.rtb1.ReadOnly = true;
            this.rtb1.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.rtb1.Size = new System.Drawing.Size(456, 720);
            this.rtb1.TabIndex = 9;
            this.rtb1.Text = "";
            // 
            // webBrowser2
            // 
            this.webBrowser2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowser2.Location = new System.Drawing.Point(5, 5);
            this.webBrowser2.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser2.Name = "webBrowser2";
            this.webBrowser2.Size = new System.Drawing.Size(3220, 1480);
            this.webBrowser2.TabIndex = 0;
            this.webBrowser2.Url = new System.Uri("http://ist.rit.edu/api/contactForm/", System.UriKind.Absolute);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(3184, 1609);
            this.Controls.Add(this.tabControl1);
            this.Margin = new System.Windows.Forms.Padding(7, 8, 7, 8);
            this.Name = "Form1";
            this.Text = "Clay Brimm Project 3";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbPeople2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPeople3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPeople1)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabControl6.ResumeLayout(false);
            this.tabPage26.ResumeLayout(false);
            this.tabPage26.PerformLayout();
            this.tabPage27.ResumeLayout(false);
            this.tabPage28.ResumeLayout(false);
            this.tabPage28.PerformLayout();
            this.tabPage29.ResumeLayout(false);
            this.tabPage29.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbAmbassador1)).EndInit();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            this.tabPage9.ResumeLayout(false);
            this.tabControl4.ResumeLayout(false);
            this.tabPage22.ResumeLayout(false);
            this.tabPage22.PerformLayout();
            this.tabPage24.ResumeLayout(false);
            this.tabPage24.PerformLayout();
            this.tabPage10.ResumeLayout(false);
            this.tabPage10.PerformLayout();
            this.tabPage11.ResumeLayout(false);
            this.gbForms2.ResumeLayout(false);
            this.gbForms1.ResumeLayout(false);
            this.tabPage12.ResumeLayout(false);
            this.tabPage12.PerformLayout();
            this.tabPage13.ResumeLayout(false);
            this.tabPage13.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.tabControl5.ResumeLayout(false);
            this.tabPage23.ResumeLayout(false);
            this.tabPage25.ResumeLayout(false);
            this.tabControl3.ResumeLayout(false);
            this.tabPage15.ResumeLayout(false);
            this.tabPage14.ResumeLayout(false);
            this.tabPage16.ResumeLayout(false);
            this.tabPage17.ResumeLayout(false);
            this.tabPage18.ResumeLayout(false);
            this.tabPage19.ResumeLayout(false);
            this.tabPage20.ResumeLayout(false);
            this.tabPage21.ResumeLayout(false);
            this.tabPage30.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbl_aboutTitle;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbl_about_quoteAuthor;
        private System.Windows.Forms.RichTextBox rtb_desc;
        private System.Windows.Forms.TextBox tb_quote;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.TabPage tabPage12;
        private System.Windows.Forms.TabPage tabPage13;
        private System.Windows.Forms.RichTextBox rtbAbroad2;
        private System.Windows.Forms.RichTextBox rtbAbroad1;
        private System.Windows.Forms.RichTextBox rtbAbroad;
        private System.Windows.Forms.RichTextBox richTextBox3;
        private System.Windows.Forms.Label lblAbroad2;
        private System.Windows.Forms.Label lblAbroad1;
        private System.Windows.Forms.LinkLabel linkServices1;
        private System.Windows.Forms.RichTextBox rtbServices1;
        private System.Windows.Forms.Label lblServices4;
        private System.Windows.Forms.Label lblServices2;
        private System.Windows.Forms.RichTextBox rtbServices4;
        private System.Windows.Forms.RichTextBox rtbServices2;
        private System.Windows.Forms.Label linkLab1;
        private System.Windows.Forms.RichTextBox rtbLab1;
        private System.Windows.Forms.Label lblLab1;
        private System.Windows.Forms.RichTextBox rtbAmbassador1;
        private System.Windows.Forms.Label lblAmbassador1;
        private System.Windows.Forms.PictureBox pbAmbassador1;
        private System.Windows.Forms.GroupBox gbForms2;
        private System.Windows.Forms.RichTextBox rtbForms2;
        private System.Windows.Forms.GroupBox gbForms1;
        private System.Windows.Forms.RichTextBox rtbForms1;
        private System.Windows.Forms.RichTextBox rtbCoop1;
        private System.Windows.Forms.Label lblCoop1;
        private System.Windows.Forms.RichTextBox rtbNews2;
        private System.Windows.Forms.RichTextBox rtbNews1;
        private System.Windows.Forms.Label lblNews2;
        private System.Windows.Forms.Label lblNews1;
        private System.Windows.Forms.Label lblCareer1;
        private System.Windows.Forms.RichTextBox rtbCareer2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RichTextBox rtbDegree1;
        private System.Windows.Forms.RichTextBox rtbDegree2;
        private System.Windows.Forms.RichTextBox rtbPeople1;
        private System.Windows.Forms.Button btnPeople1;
        private System.Windows.Forms.PictureBox pbPeople1;
        private System.Windows.Forms.Label lblPeople1;
        private System.Windows.Forms.RichTextBox rtbPeople3;
        private System.Windows.Forms.RichTextBox rtbPeople2;
        private System.Windows.Forms.Label lblPeople3;
        private System.Windows.Forms.Label lblPeople2;
        private System.Windows.Forms.PictureBox pbPeople2;
        private System.Windows.Forms.PictureBox pbPeople3;
        private System.Windows.Forms.Button btnPeople2;
        private System.Windows.Forms.Label lblPeople4;
        private System.Windows.Forms.Button btnPeople3;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage15;
        private System.Windows.Forms.TabPage tabPage14;
        private System.Windows.Forms.TabPage tabPage16;
        private System.Windows.Forms.TabPage tabPage17;
        private System.Windows.Forms.TabPage tabPage18;
        private System.Windows.Forms.TabPage tabPage19;
        private System.Windows.Forms.TabPage tabPage20;
        private System.Windows.Forms.TabPage tabPage21;
        private System.Windows.Forms.RichTextBox rtbCareer1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TabControl tabControl4;
        private System.Windows.Forms.TabPage tabPage22;
        private System.Windows.Forms.TabPage tabPage24;
        private System.Windows.Forms.TabControl tabControl5;
        private System.Windows.Forms.TabPage tabPage23;
        private System.Windows.Forms.TabPage tabPage25;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox rtbDegree3;
        private System.Windows.Forms.RichTextBox rtbDegree4;
        private System.Windows.Forms.RichTextBox rtbDegree5;
        private System.Windows.Forms.RichTextBox rtbDegree6;
        private System.Windows.Forms.RichTextBox rtbDegree7;
        private System.Windows.Forms.RichTextBox rtbDegree8;
        private System.Windows.Forms.RichTextBox rtbDegree9;
        private System.Windows.Forms.RichTextBox rtbDegree10;
        private System.Windows.Forms.TabControl tabControl6;
        private System.Windows.Forms.TabPage tabPage26;
        private System.Windows.Forms.TabPage tabPage27;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblCareer6;
        private System.Windows.Forms.Label lblCareer5;
        private System.Windows.Forms.Label lblCareer4;
        private System.Windows.Forms.Label lblCareer3;
        private System.Windows.Forms.Label lblCareer2;
        private System.Windows.Forms.WebBrowser webBrowser1;
        private System.Windows.Forms.RichTextBox rtbResearch1;
        private System.Windows.Forms.ComboBox cbResearch2;
        private System.Windows.Forms.ComboBox cbResearch1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TabPage tabPage28;
        private System.Windows.Forms.TabPage tabPage29;
        private System.Windows.Forms.TabPage tabPage30;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.RichTextBox rtbTwo;
        private System.Windows.Forms.RichTextBox rtbThree;
        private System.Windows.Forms.RichTextBox rtbFour;
        private System.Windows.Forms.RichTextBox rtbOne;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.RichTextBox rtb2;
        private System.Windows.Forms.RichTextBox rtb3;
        private System.Windows.Forms.RichTextBox rtb4;
        private System.Windows.Forms.RichTextBox rtb1;
        private System.Windows.Forms.WebBrowser webBrowser2;
    }
}

